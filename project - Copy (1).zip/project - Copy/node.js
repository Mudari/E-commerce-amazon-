// const http = require('http');
// const fs = require('fs');
// const path = require('path');

// const server = http.createServer((req, res) => {
//     let filePath = '.' + req.url;
//     if (filePath === './') {
//         filePath = './index.html';
//     }

//     const extname = path.extname(filePath);
//     let contentType = 'text/html';

//     switch (extname) {
//         case '.js':
//             contentType = 'text/javascript';
//             break;
//         case '.css':
//             contentType = 'text/css';
//             break;
//         case '.json':
//             contentType = 'application/json';
//             break;
//         case '.png':
//             contentType = 'image/png';
//             break;
//         case '.jpg':
//             contentType = 'image/jpg';
//             break;
//     }

//     fs.readFile(filePath, (err, content) => {
//         if (err) {
//             if (err.code === 'ENOENT') {
//                 fs.readFile('./404.html', (err, content) => {
//                     res.writeHead(404, { 'Content-Type': 'text/html' });
//                     res.end(content, 'utf8');
//                 });
//             } else {
//                 res.writeHead(500);
//                 res.end(`Server Error: ${err.code}`);
//             }
//         } else {
//             res.writeHead(200, { 'Content-Type': contentType });
//             res.end(content, 'utf8');
//         }
//     });
// });

// const PORT = process.env.PORT || 3000;

// server.listen(PORT, () => {
//     console.log(`Server running on port ${PORT}`);
// });









const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000; // Define the port number

const server = http.createServer((req, res) => {
    // Set the content type based on file extension
    const contentType = {
        '.html': 'text/html',
        '.css': 'text/css',
        '.js': 'text/javascript',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpg'
    };

    // Parse the requested URL
    let filePath = '.' + req.url;
    if (filePath === './') {
        filePath = './index.html'; // Default to index.html if no specific file requested
    }

    // Determine the content type based on the file extension
    const extname = path.extname(filePath);
    const contentTypeHeader = contentType[extname] || 'application/octet-stream';

    // Read the requested file
    fs.readFile(filePath, (err, content) => {
        if (err) {
            // Handle file not found error
            if (err.code === 'ENOENT') {
                fs.readFile('./404.html', (err, content) => {
                    res.writeHead(404, { 'Content-Type': 'text/html' });
                    res.end(content, 'utf8');
                });
            } else {
                // Server error
                res.writeHead(500);
                res.end(`Server Error: ${err.code}`);
            }
        } else {
            // Successful response
            res.writeHead(200, { 'Content-Type': contentTypeHeader });
            res.end(content, 'utf8');
        }
    });
});

// Start the server
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
